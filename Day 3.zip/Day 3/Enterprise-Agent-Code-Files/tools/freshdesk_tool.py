import os
import aiohttp
import base64
import ssl
from typing import Dict, Any, Optional
# Agent Framework Observability imports
from agent_framework.observability import get_tracer, get_meter
from opentelemetry.trace import SpanKind

class FreshdeskTool:
    """
    Async Freshdesk tool to create tickets via Freshdesk REST API.
    """
    def __init__(self):
        self.domain = os.getenv("FRESHDESK_DOMAIN")
        self.api_key = os.getenv("FRESHDESK_API_KEY")
        self.default_priority = int(os.getenv("FRESHDESK_DEFAULT_PRIORITY", "1") or 1)
        self.default_group_id = os.getenv("FRESHDESK_DEFAULT_GROUP_ID") or None

        if not self.domain or not self.api_key:
            raise RuntimeError("Freshdesk domain/API key missing in environment.")

        self.base_url = f"https://{self.domain}/api/v2"
        auth_bytes = f"{self.api_key}:X".encode("utf-8")
        auth_header = base64.b64encode(auth_bytes).decode("utf-8")
        self.headers = {
            "Authorization": f"Basic {auth_header}",
            "Content-Type": "application/json"
        }

    async def create_ticket(self, subject: str, description: str, requester: Optional[Dict[str, str]] = None, tags: Optional[list] = None) -> Dict[str, Any]:
        tracer = get_tracer()
        with tracer.start_as_current_span(
            name="freshdesk_create_ticket",
            kind=SpanKind.CLIENT,
            attributes={
                "freshdesk.subject": subject,
                "freshdesk.domain": self.domain,
                "freshdesk.requester": requester.get("name") if requester else "unknown",
                "freshdesk.tags": str(tags) if tags else "none"
            }
        ) as ticket_span:
            
            url = f"{self.base_url}/tickets"
            payload: Dict[str, Any] = {
                "subject": subject,
                "description": description,
                "priority": self.default_priority,
                "status": 2  # 2 = Open status in Freshdesk
            }
            if self.default_group_id:
                try:
                    payload["group_id"] = int(self.default_group_id)
                except ValueError:
                    pass
            if tags:
                payload["tags"] = tags
            if requester:
                if requester.get("email"):
                    payload["email"] = requester.get("email")
                if requester.get("name"):
                    payload["name"] = requester.get("name")

            # Create SSL context that allows insecure connections for testing
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            connector = aiohttp.TCPConnector(ssl=ssl_context)
            
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.post(url, headers=self.headers, json=payload) as resp:
                    ticket_span.set_attribute("http.status_code", resp.status)
                    
                    data = await resp.json()
                    if resp.status not in (200, 201):
                        ticket_span.set_attribute("freshdesk.error", str(data))
                        raise RuntimeError(f"Freshdesk API error {resp.status}: {data}")
                    
                    ticket_id = data.get("id")
                    ticket_span.set_attribute("freshdesk.ticket_id", str(ticket_id))
                    ticket_span.set_attribute("freshdesk.success", True)
                    
                    ticket = {
                        "id": ticket_id,
                        "status": data.get("status"),
                        "priority": data.get("priority"),
                        "url": f"https://{self.domain}/helpdesk/tickets/{ticket_id}"
                    }
                    
                    # Log ticket creation metrics
                    meter = get_meter()
                    ticket_counter = meter.create_counter("freshdesk_tickets_created", description="Count of Freshdesk tickets created")
                    ticket_counter.add(1, {
                        "domain": self.domain,
                        "success": "true",
                        "priority": str(data.get("priority"))
                    })
                    
                    return {"success": True, "ticket": ticket, "raw": data}

    async def health_check(self):
        """Check Freshdesk connectivity by fetching sample endpoint (accounts may not allow GETs; this is best-effort)."""
        try:
            url = f"{self.base_url}/agents"
            # Create SSL context that allows insecure connections for testing
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            connector = aiohttp.TCPConnector(ssl=ssl_context)
            
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.get(url, headers=self.headers) as resp:
                    return {"status": "healthy" if resp.status in (200, 403) else "unhealthy", "status_code": resp.status}
        except Exception as e:
            return {"status": "error", "error": str(e)}
