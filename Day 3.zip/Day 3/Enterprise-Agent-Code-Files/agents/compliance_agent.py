import os
import asyncio
from azure.ai.projects.aio import AIProjectClient
from agent_framework import ChatAgent
from agent_framework.azure import AzureAIAgentClient
from azure.identity.aio import AzureCliCredential

async def build_compliance_agent():
    """Build or reuse persistent compliance agent"""
    credential = AzureCliCredential()
    
    async with AIProjectClient(
        endpoint=os.getenv("AZURE_AI_PROJECT_ENDPOINT"), 
        credential=credential
    ) as project_client:
        
        # Try to find existing agent first
        agent_name = "Enterprise-ComplianceAgent"
        try:
            agents = project_client.agents.list_agents()
            async for agent in agents:
                if agent.name == agent_name:
                    # Return existing persistent agent
                    return ChatAgent(
                        chat_client=AzureAIAgentClient(
                            async_credential=credential,
                            agent_id=agent.id,
                            project_endpoint=os.getenv("AZURE_AI_PROJECT_ENDPOINT"),
                            model_deployment_name=os.getenv("AZURE_AI_MODEL_DEPLOYMENT_NAME")
                        ),
                        instructions="You are a senior compliance and legal specialist."
                    )
        except Exception:
            pass  # Continue to create new agent if listing fails
        
        # Create new persistent agent if not found
        created_agent = await project_client.agents.create_agent(
            model=os.getenv("AZURE_AI_MODEL_DEPLOYMENT_NAME"),
            name=agent_name, 
        instructions=(
            "You are a senior compliance and legal specialist with expertise in multiple jurisdictions. "
            "Provide authoritative guidance on:\n"
            "- GDPR and data protection regulations (EU, UK, US state laws)\n"
            "- Privacy policies and data processing agreements\n"
            "- Regulatory compliance (SOX, HIPAA, PCI-DSS, ISO standards)\n"
            "- Risk assessment and audit requirements\n"
            "- Contract law and vendor agreements\n"
            "- Information security policies\n"
            "- Cross-border data transfers and adequacy decisions\n"
            "- Breach notification requirements\n\n"
            "When provided CONTEXT, prefer it as the primary source. "
            "If the user asks to create a ticket (phrases like \"create a ticket\", \"submit a compliance request\", \"open a support ticket\"), output a structured block starting with:\n"
            "CREATE_TICKET\n"
            "Subject: <one-line subject>\n"
            "Body: <detailed description>\n"
            "Tags: tag1,tag2 (optional)\n"
            "Email: user@example.com (optional)\n"
            "Name: John Doe (optional)\n"
            "Return only the CREATE_TICKET block when requesting a ticket; do not call any APIs yourself.\n\n"
            "Always provide factual, well-researched answers with relevant legal citations. "
            "Include practical implementation steps and potential risks. Use formal, professional tone."
            )
        )
        
        # Return persistent agent wrapped in ChatAgent
        return ChatAgent(
            chat_client=AzureAIAgentClient(
                async_credential=credential,
                agent_id=created_agent.id,
                project_endpoint=os.getenv("AZURE_AI_PROJECT_ENDPOINT"),
                model_deployment_name=os.getenv("AZURE_AI_MODEL_DEPLOYMENT_NAME")
            ),
            instructions="You are a senior compliance and legal specialist."
        )
